package util;

public enum CloseType {
	SELF_CLOSE,
	KICKED_OUT,
	MANAGER_LEAVE,
	SERVER_CRASH,
}
